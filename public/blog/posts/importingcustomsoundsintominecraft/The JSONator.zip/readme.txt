The JSONator 
By Mental Block Gaming 

To be used in conjunction with the tutorial at http://mentalblockgaming.com/blog/sound/importing-custom-sounds-into-minecraft

The JSONator creates a sounds.json file that Minecraft uses to read the destination of custom sound files. 
This program simplifies the process of creating the sounds.json file. 

When prompted, input the location of the folder where your sound files are stored. 
Ensure that there are no other files or folders inside this folder except for .ogg files that you want to import into the game. 
Ensure that the final character in the folder's location that you input is a backslash (\). 
To find the location of the folder, right click inside the folder and select Properties. The folder location will be displayed. 

The JSONator will create the sounds.json file in the same folder as the program. 
Note that it does not save in the same locaiton as your sound files. 

When you have finished, press any key to close the program. 