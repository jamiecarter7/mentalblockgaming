#include <cstdlib>
#include <iostream>
#include <string> 
#include <windows.h>
#include <fstream>

using namespace std;
int main(int argc, char *argv[])
{
    string directory;
    cout << "Welcome to Mental Block Gaming's JSONator for Map Makers!\nInput the folder path of the directory where your sound files are stored.\nE.g. C:\\Users\\Daniel\\Documents\\Minecraft\\Sounds\\\n";
    getline( cin, directory); 
    cout << endl; 
    directory.append( "*" ); 
    static const char* chFolderpath = directory.c_str();    
    string data;
    string json = "{\n";
    int position;

    HANDLE hFind;
    WIN32_FIND_DATAA data2; 

    hFind = FindFirstFileA(chFolderpath, &data2); 

    if (hFind != INVALID_HANDLE_VALUE) 
    {
        do
        {
            if( data2.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY )
                data += "<DIR>";  

              data = data2.cFileName;

	      if (data != "." && data != "..")
	      {
	          json.append( "    \"" );
	          json.append( data );
	          json.append( "\": {\n    \"sounds\": [\n      \"custom/" );
	          json.append( data ); 
	          json.append( "\"\n    ]\n  },\n" ); 
	      }

        } while( FindNextFileA( hFind, &data2 ) );

        FindClose( hFind );
    }


    position = json.find(".ogg", 0);
    while ( position != -1 )
    { 
        json.replace(position, 4, "");
        position = json.find(".ogg", 0);
    }

    position = json.find_last_of(",");
    json.replace(position, 1, ""); 

    json.append( "}" );

//    cout << json;

    ofstream writer( "sounds.json" );

    if ( ! writer ) 
    {
       cout << "Error opening file for output" << endl;
       return -1; 
    }

    writer << json << endl;
    writer.close();

    cout << "\nFile created!\nLook for \"sounds.json\" in the folder where this program is located.\nThanks for using Mental Block Gaming's JSONator!\nGood luck with your map!\n\n" ; 

    system("PAUSE");
    return 0;
}